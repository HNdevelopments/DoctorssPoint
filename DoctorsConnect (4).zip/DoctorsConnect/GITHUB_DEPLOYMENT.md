# Ensure all changes are committed
git add .
git commit -m "Configure for GitHub Pages deployment"
git push origin main