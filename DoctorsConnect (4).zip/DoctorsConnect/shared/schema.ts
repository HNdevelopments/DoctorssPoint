import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define session table to match connect-pg-simple requirements
export const sessions = pgTable("session", {
  sid: text("sid").primaryKey(),
  sess: text("sess").notNull(),
  expire: timestamp("expire").notNull(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: ["doctor", "admin"] }).notNull(),
  name: text("name"),
  phone: text("phone"),
  experience: integer("experience"),
  qualifications: text("qualifications"),
  location: text("location"),
  specialties: text("specialties").array(),
  isActive: boolean("is_active").default(true),
  rating: integer("rating").default(0),
  ratingCount: integer("rating_count").default(0)
});

export const contactForms = pgTable("contact_forms", {
  id: serial("id").primaryKey(),
  doctorId: integer("doctor_id").notNull(),
  patientName: text("patient_name").notNull(),
  patientEmail: text("patient_email").notNull(),
  patientPhone: text("patient_phone").notNull(),
  disease: text("disease").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const generalInquiries = pgTable("general_inquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  name: true,
  phone: true,
  experience: true,
  qualifications: true,
  location: true,
  specialties: true
});

export const insertContactFormSchema = createInsertSchema(contactForms).omit({
  id: true,
  createdAt: true
});

export const insertGeneralInquirySchema = createInsertSchema(generalInquiries).omit({
  id: true,
  createdAt: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type ContactForm = typeof contactForms.$inferSelect;
export type InsertContactForm = z.infer<typeof insertContactFormSchema>;
export type InsertGeneralInquiry = z.infer<typeof insertGeneralInquirySchema>;
export type GeneralInquiry = typeof generalInquiries.$inferSelect;