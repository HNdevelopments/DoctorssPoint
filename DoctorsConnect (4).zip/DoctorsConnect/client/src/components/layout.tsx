import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-background sticky top-0 z-50">
        <div className="container mx-auto flex justify-between items-center py-4">
          <div className="flex items-center space-x-8">
            <Link href="/">
              <h1 className="text-2xl font-bold cursor-pointer">DoctorsPoint</h1>
            </Link>
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/">
                <span className="text-sm font-medium hover:text-primary cursor-pointer">Home</span>
              </Link>
              <Link href="/about">
                <span className="text-sm font-medium hover:text-primary cursor-pointer">About Us</span>
              </Link>
              <Link href="/contact">
                <span className="text-sm font-medium hover:text-primary cursor-pointer">Contact</span>
              </Link>
              <Link href="/doctors">
                <span className="text-sm font-medium hover:text-primary cursor-pointer">Find Doctors</span>
              </Link>
              <Link href="/master">
                <span className="text-sm font-medium text-primary hover:text-primary/80 cursor-pointer">
                  Master Admin
                </span>
              </Link>
            </nav>
          </div>
          <div className="space-x-4">
            {user ? (
              <>
                <Link href={user.role === 'admin' ? "/master/dashboard" : "/doctor/dashboard"}>
                  <Button className="bg-black text-white hover:bg-black/90">
                    {user.role === 'admin' ? "Admin Dashboard" : "Doctor Dashboard"}
                  </Button>
                </Link>
              </>
            ) : (
              <Link href="/auth">
                <Button className="bg-black text-white hover:bg-black/90">Join as Doctor</Button>
              </Link>
            )}
          </div>
        </div>
      </header>
      <main>{children}</main>
      <footer className="bg-background border-t py-12">
        <div className="container mx-auto grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold mb-4">DoctorsPoint</h3>
            <p className="text-sm text-muted-foreground">
              Connecting patients with qualified healthcare professionals
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <div className="space-y-2">
              <Link href="/about">
                <span className="block text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  About Us
                </span>
              </Link>
              <Link href="/contact">
                <span className="block text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  Contact
                </span>
              </Link>
              <Link href="/doctors">
                <span className="block text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  Find Doctors
                </span>
              </Link>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-4">For Doctors</h4>
            <div className="space-y-2">
              <Link href="/auth">
                <span className="block text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  Join as Doctor
                </span>
              </Link>
              <Link href="/doctor/dashboard">
                <span className="block text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  Doctor Portal
                </span>
              </Link>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Contact Us</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>Email: support@doctorspoint.com</p>
              <p>Phone: +1 234 567 890</p>
              <p>Address: 123 Medical Plaza, Healthcare City</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}