import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User, insertContactFormSchema } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Star, Search, MapPin, Phone, Award, GraduationCap } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";
import { Textarea } from "@/components/ui/textarea";
import { z } from "zod";

type ContactFormValues = z.infer<typeof insertContactFormSchema>;

export default function DoctorsPage() {
  const [search, setSearch] = useState("");
  const { toast } = useToast();
  const [selectedDoctor, setSelectedDoctor] = useState<User | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: doctors = [] } = useQuery<User[]>({
    queryKey: ["/api/doctors"],
  });

  const contactForm = useForm({
    resolver: zodResolver(insertContactFormSchema),
    defaultValues: {
      patientName: "",
      patientEmail: "",
      patientPhone: "",
      disease: "",
      message: "",
      doctorId: 0
    },
  });

  const filteredDoctors = doctors.filter(
    (doctor) =>
      doctor.isActive &&
      (doctor.name?.toLowerCase().includes(search.toLowerCase()) ||
        doctor.specialties?.some((s) => s.toLowerCase().includes(search.toLowerCase())))
  );

  const handleContactSubmit = async (formData: ContactFormValues) => {
    try {
      if (!selectedDoctor) {
        throw new Error("Please select a doctor before submitting");
      }

      const response = await apiRequest("POST", "/api/contact", {
        ...formData,
        doctorId: selectedDoctor.id
      });

      toast({
        title: "Success",
        description: "Your message has been sent to the doctor",
      });

      contactForm.reset();
      setDialogOpen(false);
      setSelectedDoctor(null);

      await queryClient.invalidateQueries({ queryKey: ["/api/doctors"] });
    } catch (error: any) {
      console.error("Contact form submission error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleRating = async (doctorId: number, rating: number) => {
    try {
      await apiRequest("POST", `/api/doctors/${doctorId}/rate`, { rating });
      await queryClient.invalidateQueries({ queryKey: ["/api/doctors"] });
      toast({
        title: "Success",
        description: "Thank you for rating the doctor",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to submit rating",
        variant: "destructive",
      });
    }
  };

  return (
    <Layout>
      <div className="bg-gradient-to-b from-primary/5 to-background border-b py-16">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Find Your Perfect Doctor</h2>
          <div className="max-w-xl mx-auto flex gap-2">
            <Input
              placeholder="Search by name or specialty..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-white"
            />
            <Button className="bg-black text-white hover:bg-black/90">
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoctors.map((doctor: User) => (
            <Card key={doctor.id} className="overflow-hidden">
              <img
                src={`https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=500`}
                alt={doctor.name || "Doctor"}
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h2 className="text-xl font-bold">{doctor.name}</h2>
                    <div className="flex items-center text-muted-foreground">
                      <MapPin className="h-4 w-4 mr-1" />
                      {doctor.location}
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span className="ml-1">{doctor.rating}/5</span>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-muted-foreground">
                    <Phone className="h-4 w-4 mr-2" />
                    {doctor.phone}
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Award className="h-4 w-4 mr-2" />
                    {doctor.experience} years experience
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <GraduationCap className="h-4 w-4 mr-2" />
                    {doctor.qualifications}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {doctor.specialties?.map((specialty: string, index: number) => (
                    <span
                      key={`${specialty}-${index}`}
                      className="px-2 py-1 bg-primary/10 text-primary rounded-full text-sm"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>

                <div className="flex justify-between">
                  <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                    <DialogTrigger asChild>
                      <Button
                        className="bg-black text-white hover:bg-black/90"
                        onClick={() => {
                          setSelectedDoctor(doctor);
                          contactForm.reset();
                        }}
                      >
                        Contact
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Contact Dr. {selectedDoctor?.name}</DialogTitle>
                      </DialogHeader>
                      <Form {...contactForm}>
                        <form onSubmit={contactForm.handleSubmit(handleContactSubmit)} className="space-y-4">
                          <FormField
                            control={contactForm.control}
                            name="patientName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Your Name</FormLabel>
                                <Input {...field} placeholder="John Doe" />
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={contactForm.control}
                            name="patientEmail"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email</FormLabel>
                                <Input type="email" {...field} placeholder="john@example.com" />
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={contactForm.control}
                            name="patientPhone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Phone</FormLabel>
                                <Input {...field} placeholder="+1 (555) 000-0000" />
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={contactForm.control}
                            name="disease"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Disease/Condition</FormLabel>
                                <Input {...field} placeholder="Describe your condition" />
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={contactForm.control}
                            name="message"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Message</FormLabel>
                                <Textarea
                                  {...field}
                                  placeholder="Write your message here..."
                                  className="min-h-[100px]"
                                />
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <Button
                            type="submit"
                            className="w-full bg-black text-white hover:bg-black/90"
                          >
                            Send Message
                          </Button>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>

                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-5 w-5 cursor-pointer ${
                          star <= (doctor.rating || 0) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                        }`}
                        onClick={() => handleRating(doctor.id, star)}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}