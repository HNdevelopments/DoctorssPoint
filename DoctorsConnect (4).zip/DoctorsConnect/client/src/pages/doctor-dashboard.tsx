import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { ContactForm } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";

export default function DoctorDashboard() {
  const { user, logoutMutation } = useAuth();

  const { data: contactForms = [] } = useQuery<ContactForm[]>({
    queryKey: [`/api/contact/${user?.id}`],
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-background">
        <div className="container mx-auto flex justify-between items-center py-4">
          <div>
            <h1 className="text-2xl font-bold">Doctor Dashboard</h1>
            <p className="text-sm text-muted-foreground">Welcome, Dr. {user?.name}</p>
          </div>
          <Button variant="outline" onClick={() => logoutMutation.mutate()}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <main className="container mx-auto py-8">
        <Card>
          <CardHeader>
            <CardTitle>Patient Inquiries</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {contactForms.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No inquiries yet
                </p>
              ) : (
                contactForms.map((form) => (
                  <Card key={form.id}>
                    <CardContent className="p-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <h3 className="font-semibold">{form.patientName}</h3>
                          <p className="text-sm text-muted-foreground">
                            {form.patientEmail}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {form.patientPhone}
                          </p>
                        </div>
                        <div>
                          <p className="font-medium">Disease: {form.disease}</p>
                          <p className="text-sm mt-2">{form.message}</p>
                          <p className="text-xs text-muted-foreground mt-2">
                            Received: {new Date(form.createdAt!).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}