import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { ContactForm, User, GeneralInquiry } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { LogOut, Power, PowerOff, Star } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

export default function MasterAdminPage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();

  const { data: doctors = [] } = useQuery<User[]>({
    queryKey: ["/api/doctors"],
  });

  const { data: contactForms = [] } = useQuery<ContactForm[]>({
    queryKey: ["/api/admin/contacts"],
  });

  const { data: generalInquiries = [] } = useQuery<GeneralInquiry[]>({
    queryKey: ["/api/admin/inquiries"],
  });

  if (user?.role !== 'admin') {
    return <div>Access Denied</div>;
  }

  const handleToggleDoctor = async (doctorId: number) => {
    try {
      await apiRequest("POST", `/api/admin/doctors/${doctorId}/toggle`);
      queryClient.invalidateQueries({ queryKey: ["/api/doctors"] });
      toast({
        title: "Success",
        description: "Doctor status updated",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        <header className="border-b bg-background">
          <div className="container mx-auto flex justify-between items-center py-4">
            <div>
              <h1 className="text-2xl font-bold">Master Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Welcome, {user?.name}</p>
            </div>
            <Button variant="outline" onClick={() => logoutMutation.mutate()}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </header>

        <main className="container mx-auto py-8">
          <Tabs defaultValue="doctors">
            <TabsList className="mb-8">
              <TabsTrigger value="doctors">Manage Doctors</TabsTrigger>
              <TabsTrigger value="inquiries">Patient Inquiries</TabsTrigger>
              <TabsTrigger value="general-inquiries">General Inquiries</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            {/* Doctors Tab */}
            <TabsContent value="doctors">
              <Card>
                <CardHeader>
                  <CardTitle>Registered Doctors</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Specialties</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Rating</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {doctors
                        .filter((d) => d.role === "doctor")
                        .map((doctor) => (
                          <TableRow key={doctor.id}>
                            <TableCell className="font-medium">{doctor.name}</TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1">
                                {doctor.specialties?.map((specialty) => (
                                  <Badge key={specialty} variant="secondary">
                                    {specialty}
                                  </Badge>
                                ))}
                              </div>
                            </TableCell>
                            <TableCell>{doctor.location}</TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <Star className="h-4 w-4 text-yellow-400 mr-1" />
                                {doctor.rating}/5 ({doctor.ratingCount} reviews)
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant={doctor.isActive ? "outline" : "destructive"}>
                                {doctor.isActive ? "Active" : "Inactive"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Button
                                variant={doctor.isActive ? "destructive" : "default"}
                                size="sm"
                                onClick={() => handleToggleDoctor(doctor.id)}
                              >
                                {doctor.isActive ? (
                                  <PowerOff className="h-4 w-4 mr-2" />
                                ) : (
                                  <Power className="h-4 w-4 mr-2" />
                                )}
                                {doctor.isActive ? "Deactivate" : "Activate"}
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Patient Inquiries Tab */}
            <TabsContent value="inquiries">
              <Card>
                <CardHeader>
                  <CardTitle>Patient Inquiries</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Patient</TableHead>
                        <TableHead>Doctor</TableHead>
                        <TableHead>Disease</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {contactForms.map((form) => (
                        <TableRow key={form.id}>
                          <TableCell className="font-medium">
                            {form.patientName}
                          </TableCell>
                          <TableCell>
                            {doctors.find(d => d.id === form.doctorId)?.name}
                          </TableCell>
                          <TableCell>{form.disease}</TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div>{form.patientEmail}</div>
                              <div className="text-muted-foreground">
                                {form.patientPhone}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            {new Date(form.createdAt!).toLocaleDateString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* General Inquiries Tab */}
            <TabsContent value="general-inquiries">
              <Card>
                <CardHeader>
                  <CardTitle>General Inquiries</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Subject</TableHead>
                        <TableHead>Message</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {generalInquiries.map((inquiry) => (
                        <TableRow key={inquiry.id}>
                          <TableCell className="font-medium">
                            {inquiry.name}
                          </TableCell>
                          <TableCell>{inquiry.email}</TableCell>
                          <TableCell>{inquiry.subject}</TableCell>
                          <TableCell>
                            <div className="max-w-[300px] truncate">
                              {inquiry.message}
                            </div>
                          </TableCell>
                          <TableCell>
                            {new Date(inquiry.createdAt!).toLocaleDateString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Total Doctors</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-4xl font-bold">
                      {doctors.filter(d => d.role === "doctor").length}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Active Doctors</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-4xl font-bold">
                      {doctors.filter(d => d.role === "doctor" && d.isActive).length}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Patient Inquiries</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-4xl font-bold">
                      {contactForms.length}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>General Inquiries</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-4xl font-bold">
                      {generalInquiries.length}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </Layout>
  );
}