import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { ContactForm, User, GeneralInquiry } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LogOut, Power, PowerOff } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

export default function AdminDashboard() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();

  const { data: doctors = [] } = useQuery<User[]>({
    queryKey: ["/api/doctors"],
  });

  const { data: generalInquiries = [] } = useQuery<GeneralInquiry[]>({
    queryKey: ["/api/admin/inquiries"],
  });

  const handleToggleDoctor = async (doctorId: number) => {
    try {
      await apiRequest("POST", `/api/admin/doctors/${doctorId}/toggle`);
      queryClient.invalidateQueries({ queryKey: ["/api/doctors"] });
      toast({
        title: "Success",
        description: "Doctor status updated",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background">
        <header className="border-b bg-background">
          <div className="container mx-auto flex justify-between items-center py-4">
            <div>
              <h1 className="text-2xl font-bold">Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Welcome, {user?.name}</p>
            </div>
            <Button variant="outline" onClick={() => logoutMutation.mutate()}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </header>

        <main className="container mx-auto py-8">
          <Tabs defaultValue="doctors" className="space-y-4">
            <TabsList>
              <TabsTrigger value="doctors">Manage Doctors</TabsTrigger>
              <TabsTrigger value="contact-forms">Contact Forms</TabsTrigger>
            </TabsList>

            <TabsContent value="doctors">
              <Card>
                <CardHeader>
                  <CardTitle>Registered Doctors</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {doctors
                      .filter((d) => d.role === "doctor")
                      .map((doctor) => (
                        <Card key={doctor.id}>
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="font-semibold">{doctor.name}</h3>
                                <p className="text-sm text-muted-foreground">
                                  {doctor.qualifications}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {doctor.location}
                                </p>
                                <div className="flex flex-wrap gap-2 mt-2">
                                  {doctor.specialties?.map((specialty) => (
                                    <span
                                      key={specialty}
                                      className="px-2 py-1 bg-accent text-accent-foreground rounded-full text-sm"
                                    >
                                      {specialty}
                                    </span>
                                  ))}
                                </div>
                              </div>
                              <Button
                                variant={doctor.isActive ? "destructive" : "default"}
                                onClick={() => handleToggleDoctor(doctor.id)}
                              >
                                {doctor.isActive ? (
                                  <PowerOff className="h-4 w-4 mr-2" />
                                ) : (
                                  <Power className="h-4 w-4 mr-2" />
                                )}
                                {doctor.isActive ? "Deactivate" : "Activate"}
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="contact-forms">
              <Card>
                <CardHeader>
                  <CardTitle>Contact Form Submissions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {generalInquiries.map((inquiry) => (
                      <Card key={inquiry.id}>
                        <CardContent className="p-4">
                          <div className="flex flex-col gap-2">
                            <div className="flex justify-between">
                              <h3 className="font-semibold">{inquiry.name}</h3>
                              <span className="text-sm text-muted-foreground">
                                {new Date(inquiry.createdAt!).toLocaleString()}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {inquiry.email}
                            </p>
                            <p className="font-medium mt-2">{inquiry.subject}</p>
                            <p className="text-sm bg-secondary/10 p-3 rounded-lg">
                              {inquiry.message}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </Layout>
  );
}