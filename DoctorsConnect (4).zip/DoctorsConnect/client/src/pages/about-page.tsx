import { Layout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Award, Users, Heart, Shield } from "lucide-react";

export default function AboutPage() {
  return (
    <Layout>
      <div className="py-12 bg-primary/5">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl font-bold mb-4">About DoctorsPoint</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            We're dedicated to making healthcare more accessible by connecting patients
            with the right medical professionals through our innovative platform.
          </p>
        </div>
      </div>

      <div className="container mx-auto py-16">
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
            <p className="text-lg text-muted-foreground mb-8">
              To revolutionize healthcare accessibility by creating a seamless
              connection between patients and qualified medical professionals,
              ensuring everyone has access to quality healthcare when they need it.
            </p>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Trusted Platform</h3>
                  <p className="text-muted-foreground">
                    All doctors are verified and credentialed
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Heart className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Patient-Centric</h3>
                  <p className="text-muted-foreground">
                    Focused on providing the best patient experience
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div>
            <img
              src="https://images.unsplash.com/photo-1631217868264-e5b90bb4fbd1?w=800"
              alt="Medical team"
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>

        <div className="mt-24">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Us</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="p-3 bg-primary/10 rounded-full w-fit mx-auto mb-4">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Expert Doctors</h3>
                  <p className="text-sm text-muted-foreground">
                    Access to a network of qualified and experienced medical professionals
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="p-3 bg-primary/10 rounded-full w-fit mx-auto mb-4">
                    <Shield className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Secure Platform</h3>
                  <p className="text-sm text-muted-foreground">
                    Your health information is protected with industry-standard security
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="p-3 bg-primary/10 rounded-full w-fit mx-auto mb-4">
                    <Award className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Quality Care</h3>
                  <p className="text-sm text-muted-foreground">
                    Commitment to providing the highest standard of healthcare services
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
