import { z } from "zod";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { X, UserPlus, LogIn, Stethoscope } from "lucide-react";

// Enhanced schema with all fields required
const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(1, "Confirm password is required"),
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  name: z.string().min(1, "Full name is required"),
  phone: z.string().min(10, "Valid phone number is required"),
  experience: z.number().min(0, "Experience years required"),
  qualifications: z.string().min(1, "Qualifications are required"),
  location: z.string().min(1, "Location is required"),
  specialties: z.array(z.string()).min(1, "At least one specialty is required")
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [newSpecialty, setNewSpecialty] = useState("");
  const [newQualification, setNewQualification] = useState("");

  const loginForm = useForm({
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const registerForm = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      role: "doctor" as const,
      name: "",
      phone: "",
      experience: 0,
      qualifications: "",
      location: "",
      specialties: [] as string[]  // Explicitly type as string array
    },
  });

  if (user) {
    return <Redirect to={user.role === "admin" ? "/admin/dashboard" : "/doctor/dashboard"} />;
  }

  const handleAddSpecialty = () => {
    if (newSpecialty.trim()) {
      const currentSpecialties = registerForm.getValues("specialties") || [];
      registerForm.setValue("specialties", [...currentSpecialties, newSpecialty.trim()]);
      setNewSpecialty("");
    }
  };

  const handleRemoveSpecialty = (specialty: string) => {
    const currentSpecialties = registerForm.getValues("specialties");
    registerForm.setValue(
      "specialties",
      currentSpecialties.filter((s: string) => s !== specialty)
    );
  };

  const handleAddQualification = () => {
    if (newQualification.trim()) {
      const currentQualifications = registerForm.getValues("qualifications");
      const updatedQualifications = currentQualifications
        ? `${currentQualifications}, ${newQualification.trim()}`
        : newQualification.trim();
      registerForm.setValue("qualifications", updatedQualifications);
      setNewQualification("");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-primary/5 flex items-center justify-center p-4">
      <div className="container max-w-6xl mx-auto grid md:grid-cols-2 gap-8 items-center">
        {/* Left side: Hero content */}
        <div className="text-center md:text-left space-y-6">
          <div className="flex items-center justify-center md:justify-start gap-2 text-4xl font-bold text-primary">
            <Stethoscope className="h-12 w-12" />
            <span>DoctorsPoint</span>
          </div>
          <h1 className="text-3xl font-bold">Welcome to Our Medical Platform</h1>
          <p className="text-muted-foreground text-lg">
            Join our network of qualified healthcare professionals and connect with patients who need your expertise.
          </p>
          <div className="grid grid-cols-2 gap-4 max-w-md mx-auto md:mx-0">
            <div className="p-4 bg-primary/5 rounded-lg transition-all duration-300 ease-in-out hover:bg-primary/10 hover:scale-105 hover:shadow-lg">
              <h3 className="font-semibold">Fast & Easy</h3>
              <p className="text-sm text-muted-foreground">Quick registration process</p>
            </div>
            <div className="p-4 bg-primary/5 rounded-lg transition-all duration-300 ease-in-out hover:bg-primary/10 hover:scale-105 hover:shadow-lg">
              <h3 className="font-semibold">Secure</h3>
              <p className="text-sm text-muted-foreground">Your data is protected</p>
            </div>
          </div>
        </div>

        {/* Right side: Auth forms */}
        <Card className="shadow-xl transition-all duration-300 ease-in-out hover:shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center transition-colors duration-300 ease-in-out hover:text-primary">Doctor Portal</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="space-y-6">
              <TabsList className="grid grid-cols-2 transition-all duration-300 ease-in-out">
                <TabsTrigger
                  value="login"
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300 ease-in-out hover:bg-primary/10"
                >
                  <LogIn className="h-4 w-4 mr-2" />
                  Login
                </TabsTrigger>
                <TabsTrigger
                  value="register"
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300 ease-in-out hover:bg-primary/10"
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Register
                </TabsTrigger>
              </TabsList>

              <TabsContent
                value="login"
                className="transition-all duration-300 ease-in-out data-[state=inactive]:opacity-0 data-[state=active]:opacity-100"
              >
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit((data) => loginMutation.mutate(data))} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <Input placeholder="Enter your username" className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary" {...field} />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <Input type="password" placeholder="Enter your password" className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary" {...field} />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      className="w-full bg-black text-white hover:bg-black/90 transition-all duration-300 ease-in-out hover:scale-[1.02]"
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? "Logging in..." : "Login"}
                    </Button>
                  </form>
                </Form>
              </TabsContent>

              <TabsContent
                value="register"
                className="transition-all duration-300 ease-in-out data-[state=inactive]:opacity-0 data-[state=active]:opacity-100"
              >
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit((data) => registerMutation.mutate({ ...data, role: "doctor" }))} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <Input placeholder="Choose a username" className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary" {...field} />
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <Input placeholder="Dr. John Doe" className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary" {...field} />
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <Input type="password" placeholder="Choose a strong password" className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary" {...field} />
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Confirm Password</FormLabel>
                            <Input type="password" placeholder="Confirm your password" className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary" {...field} />
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="space-y-4">
                      <FormField
                        control={registerForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <Input placeholder="Your contact number" className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary" {...field} />
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="grid md:grid-cols-2 gap-4">
                        <FormField
                          control={registerForm.control}
                          name="experience"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Years of Experience</FormLabel>
                              <Input
                                type="number"
                                placeholder="Years of experience"
                                className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary"
                                {...field}
                                onChange={(e) => field.onChange(e.target.valueAsNumber)}
                              />
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={registerForm.control}
                          name="location"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Location</FormLabel>
                              <Input placeholder="Your clinic location" className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary" {...field} />
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={registerForm.control}
                        name="qualifications"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Qualifications</FormLabel>
                            <div className="flex gap-2">
                              <Input
                                placeholder="Add qualification (e.g., MBBS)"
                                value={newQualification}
                                onChange={(e) => setNewQualification(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddQualification())}
                                className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary"
                              />
                              <Button
                                type="button"
                                onClick={handleAddQualification}
                                className="bg-black text-white hover:bg-black/90 transition-all duration-300 ease-in-out hover:scale-[1.02]"
                              >
                                Add
                              </Button>
                            </div>
                            <div className="mt-2">
                              <Input readOnly value={field.value} className="bg-muted" />
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={registerForm.control}
                        name="specialties"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Specialties</FormLabel>
                            <div className="flex gap-2">
                              <Input
                                placeholder="Add specialty (e.g., Cardiology)"
                                value={newSpecialty}
                                onChange={(e) => setNewSpecialty(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSpecialty())}
                                className="transition-all duration-300 ease-in-out hover:border-primary focus:border-primary"
                              />
                              <Button
                                type="button"
                                onClick={handleAddSpecialty}
                                className="bg-black text-white hover:bg-black/90 transition-all duration-300 ease-in-out hover:scale-[1.02]"
                              >
                                Add
                              </Button>
                            </div>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {field.value.map((specialty) => (
                                <div
                                  key={specialty}
                                  className="flex items-center gap-1 bg-primary/10 text-primary rounded-full px-3 py-1 transition-all duration-300 ease-in-out hover:bg-primary/20"
                                >
                                  {specialty}
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveSpecialty(specialty)}
                                    className="hover:text-primary/80 transition-colors duration-300 ease-in-out"
                                  >
                                    <X className="h-4 w-4" />
                                  </button>
                                </div>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-black text-white hover:bg-black/90 transition-all duration-300 ease-in-out hover:scale-[1.02]"
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                    </Button>
                  </form>
                </Form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}