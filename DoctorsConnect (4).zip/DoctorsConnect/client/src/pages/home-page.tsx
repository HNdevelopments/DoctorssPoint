import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User, insertContactFormSchema } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Star, Search, MapPin, Phone, Award, GraduationCap, Heart, Users, Shield } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

export default function HomePage() {
  const [search, setSearch] = useState("");
  const { toast } = useToast();
  const [selectedDoctor, setSelectedDoctor] = useState<User | null>(null);
  const [rating, setRating] = useState(0);

  const { data: doctors = [] } = useQuery<User[]>({
    queryKey: ["/api/doctors"],
  });

  const contactForm = useForm({
    resolver: zodResolver(insertContactFormSchema),
    defaultValues: {
      patientName: "",
      patientEmail: "",
      patientPhone: "",
      disease: "",
      message: "",
    },
  });

  const filteredDoctors = doctors.filter(
    (doctor) =>
      doctor.isActive &&
      (doctor.name?.toLowerCase().includes(search.toLowerCase()) ||
        doctor.specialties?.some((s) => s.toLowerCase().includes(search.toLowerCase())))
  );

  const handleContactSubmit = async (data: any) => {
    if (!selectedDoctor) return;

    try {
      await apiRequest("POST", `/api/contact/${selectedDoctor.id}`, data);
      toast({
        title: "Success",
        description: "Your message has been sent to the doctor",
      });
      contactForm.reset();
      setSelectedDoctor(null);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleRating = async (doctorId: number, rating: number) => {
    try {
      await apiRequest("POST", `/api/doctors/${doctorId}/rate`, { rating });
      toast({
        title: "Success",
        description: "Thank you for rating the doctor",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <Layout>
      <div className="bg-gradient-to-b from-primary/5 to-background border-b py-24">
        <div className="container mx-auto text-center">
          <h2 className="text-5xl font-bold mb-6">Find Your Perfect Doctor</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Connect with qualified healthcare professionals and get the care you deserve
          </p>
          <div className="max-w-xl mx-auto flex gap-2">
            <Input
              placeholder="Search by name or specialty..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-white"
            />
            <Button className="bg-black text-white hover:bg-black/90">
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-16">
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="p-3 bg-primary/10 rounded-full w-fit mx-auto mb-4">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Expert Doctors</h3>
                <p className="text-sm text-muted-foreground">
                  Access to a network of qualified and experienced medical professionals
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="p-3 bg-primary/10 rounded-full w-fit mx-auto mb-4">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Secure Platform</h3>
                <p className="text-sm text-muted-foreground">
                  Your health information is protected with industry-standard security
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="p-3 bg-primary/10 rounded-full w-fit mx-auto mb-4">
                  <Heart className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Quality Care</h3>
                <p className="text-sm text-muted-foreground">
                  Commitment to providing the highest standard of healthcare services
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoctors.map((doctor) => (
            <Card key={doctor.id} className="overflow-hidden">
              <img
                src={`https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=500`}
                alt={doctor.name}
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h2 className="text-xl font-bold">{doctor.name}</h2>
                    <div className="flex items-center text-muted-foreground">
                      <MapPin className="h-4 w-4 mr-1" />
                      {doctor.location}
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span className="ml-1">{doctor.rating}/5</span>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-muted-foreground">
                    <Phone className="h-4 w-4 mr-2" />
                    {doctor.phone}
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Award className="h-4 w-4 mr-2" />
                    {doctor.experience} years experience
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <GraduationCap className="h-4 w-4 mr-2" />
                    {doctor.qualifications}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {doctor.specialties?.map((specialty) => (
                    <span
                      key={specialty}
                      className="px-2 py-1 bg-primary/10 text-primary rounded-full text-sm"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>

                <div className="flex justify-between">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        className="bg-black text-white hover:bg-black/90"
                        onClick={() => setSelectedDoctor(doctor)}
                      >
                        Contact
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Contact Dr. {doctor.name}</DialogTitle>
                      </DialogHeader>
                      <Form {...contactForm}>
                        <form onSubmit={contactForm.handleSubmit(handleContactSubmit)} className="space-y-4">
                          <Input
                            placeholder="Your Name"
                            {...contactForm.register("patientName")}
                          />
                          <Input
                            placeholder="Your Email"
                            {...contactForm.register("patientEmail")}
                          />
                          <Input
                            placeholder="Your Phone"
                            {...contactForm.register("patientPhone")}
                          />
                          <Input
                            placeholder="Disease/Condition"
                            {...contactForm.register("disease")}
                          />
                          <Input
                            placeholder="Message"
                            {...contactForm.register("message")}
                          />
                          <Button type="submit" className="w-full bg-black text-white hover:bg-black/90">
                            Send Message
                          </Button>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>

                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-5 w-5 cursor-pointer ${
                          star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                        }`}
                        onClick={() => {
                          setRating(star);
                          handleRating(doctor.id, star);
                        }}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}