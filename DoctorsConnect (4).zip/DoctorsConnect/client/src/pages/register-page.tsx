import { z } from "zod";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Redirect, Link } from "wouter";
import { Layout } from "@/components/layout";
import { X } from "lucide-react";

// Enhanced schema with all fields required
const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(1, "Confirm password is required"),
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  name: z.string().min(1, "Full name is required"),
  phone: z.string().min(10, "Valid phone number is required"),
  experience: z.number().min(0, "Experience years required"),
  qualifications: z.string().min(1, "Qualifications are required"),
  location: z.string().min(1, "Location is required"),
  specialties: z.array(z.string()).min(1, "At least one specialty is required")
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function RegisterPage() {
  const { user, registerMutation } = useAuth();
  const [newSpecialty, setNewSpecialty] = useState("");
  const [newQualification, setNewQualification] = useState("");

  const registerForm = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      role: "doctor" as const,
      name: "",
      phone: "",
      experience: 0,
      qualifications: "",
      location: "",
      specialties: [],
    },
  });

  if (user) {
    return <Redirect to={user.role === "admin" ? "/admin/dashboard" : "/doctor/dashboard"} />;
  }

  const handleAddSpecialty = () => {
    if (newSpecialty.trim()) {
      const currentSpecialties = registerForm.getValues("specialties") || [];
      if (!currentSpecialties.includes(newSpecialty.trim())) {
        registerForm.setValue("specialties", [...currentSpecialties, newSpecialty.trim()]);
      }
      setNewSpecialty("");
    }
  };

  const handleRemoveSpecialty = (specialty: string) => {
    const currentSpecialties = registerForm.getValues("specialties");
    registerForm.setValue(
      "specialties",
      currentSpecialties.filter((s) => s !== specialty)
    );
  };

  const handleAddQualification = () => {
    if (newQualification.trim()) {
      const currentQualifications = registerForm.getValues("qualifications");
      const updatedQualifications = currentQualifications
        ? `${currentQualifications}, ${newQualification.trim()}`
        : newQualification.trim();
      registerForm.setValue("qualifications", updatedQualifications);
      setNewQualification("");
    }
  };

  const onSubmit = (data: z.infer<typeof registerSchema>) => {
    registerMutation.mutate({
      ...data,
      role: "doctor",
    });
  };

  return (
    <Layout>
      <div className="min-h-screen py-12">
        <div className="container mx-auto">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Register as Doctor</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <Input placeholder="Choose a username for login" {...field} />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <Input placeholder="Enter your full name" {...field} />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <Input type="password" placeholder="Choose a strong password" {...field} />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <Input type="password" placeholder="Confirm your password" {...field} />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <Input placeholder="Your contact number" {...field} />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="experience"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Years of Experience</FormLabel>
                          <Input
                            type="number"
                            placeholder="Years of medical experience"
                            {...field}
                            onChange={(e) => field.onChange(e.target.valueAsNumber)}
                          />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <Input placeholder="Your clinic/hospital location" {...field} />
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Qualifications Section */}
                    <div className="md:col-span-2">
                      <FormField
                        control={registerForm.control}
                        name="qualifications"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Qualifications</FormLabel>
                            <div className="flex gap-2">
                              <Input
                                placeholder="Add a qualification (e.g., MBBS, MD)"
                                value={newQualification}
                                onChange={(e) => setNewQualification(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddQualification())}
                              />
                              <Button
                                type="button"
                                onClick={handleAddQualification}
                                className="bg-black text-white hover:bg-black/90"
                              >
                                Add
                              </Button>
                            </div>
                            <div className="mt-2">
                              <Input readOnly value={field.value} className="bg-muted" />
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Specialties Section */}
                    <div className="md:col-span-2">
                      <FormField
                        control={registerForm.control}
                        name="specialties"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Specialties</FormLabel>
                            <div className="flex gap-2">
                              <Input
                                placeholder="Add a specialty (e.g., Cardiology)"
                                value={newSpecialty}
                                onChange={(e) => setNewSpecialty(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSpecialty())}
                              />
                              <Button
                                type="button"
                                onClick={handleAddSpecialty}
                                className="bg-black text-white hover:bg-black/90"
                              >
                                Add
                              </Button>
                            </div>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {field.value.map((specialty) => (
                                <div
                                  key={specialty}
                                  className="flex items-center gap-1 bg-primary/10 text-primary rounded-full px-3 py-1"
                                >
                                  {specialty}
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveSpecialty(specialty)}
                                    className="hover:text-primary/80"
                                  >
                                    <X className="h-4 w-4" />
                                  </button>
                                </div>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-black text-white hover:bg-black/90"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? "Registering..." : "Register as Doctor"}
                  </Button>
                  <p className="text-center text-sm text-muted-foreground">
                    Already have an account?{" "}
                    <Link href="/auth">
                      <span className="text-primary cursor-pointer hover:underline">
                        Login here
                      </span>
                    </Link>
                  </p>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}