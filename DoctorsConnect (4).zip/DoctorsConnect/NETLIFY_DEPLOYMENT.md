# Netlify Deployment Guide

## 1. Prerequisites
- Ensure you have a Netlify account
- Your PostgreSQL database is already set up and accessible

## 2. Deploy to Netlify

### Manual Deployment
1. Go to [Netlify](https://app.netlify.com)
2. Click "Add new site" → "Import an existing project"
3. Connect to your Git provider and select your repository
4. Configure build settings:
   - Build command: `chmod +x build.sh && ./build.sh`
   - Publish directory: `dist/public`

### Environment Variables Setup
1. Go to Site settings → Environment variables
2. Add the following variables:
   - `DATABASE_URL`: Your external PostgreSQL database URL
   - `SESSION_SECRET`: A secure random string for session management
   - `MASTER_PASSWORD`: Your admin password
   - `NODE_ENV`: Set to `production`

## 3. Domain Setup
1. Go to "Domain settings" in your Netlify dashboard
2. Add your custom domain or use the default Netlify subdomain

## 4. Verify Deployment
1. Wait for the initial deployment to complete
2. Visit your Netlify URL to ensure:
   - The frontend loads correctly
   - API endpoints connect to your database
   - User authentication works
   - Doctor listings are visible

## 5. Troubleshooting
- Check Netlify deployment logs for build errors
- Verify environment variables are correctly set
- Ensure your database is accessible from Netlify's servers
- Check the Functions log in Netlify for any backend errors

Note: Each push to your main branch will trigger a new deployment on Netlify.