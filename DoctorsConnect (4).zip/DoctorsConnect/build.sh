#!/bin/bash

# Build the frontend
echo "Building frontend..."
npm run build

# Create the functions directory
mkdir -p dist/functions

# Move server files to functions
echo "Setting up serverless functions..."
cp -r server/* dist/functions/

# Create the API handler
cat > dist/functions/api.js << 'EOL'
import express from 'express';
import serverless from 'serverless-http';
import { registerRoutes } from './routes';

const app = express();
app.use(express.json());

const server = await registerRoutes(app);
export const handler = serverless(app);
EOL

echo "Build complete!"
