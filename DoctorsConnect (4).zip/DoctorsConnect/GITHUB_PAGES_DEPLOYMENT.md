# GitHub Pages Deployment Guide

## 1. Repository Setup
1. Create a new GitHub repository if you haven't already
2. Initialize Git in your project:
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/your-username/your-repo-name.git
git push -u origin main
```

## 2. Configure GitHub Secrets
1. Go to your GitHub repository → Settings → Secrets and variables → Actions
2. Add the following secrets:
   - `DATABASE_URL`: Your external PostgreSQL database URL
   - `SESSION_SECRET`: A secure random string for session management
   - `MASTER_PASSWORD`: Your admin password for managing doctors
   - `VITE_API_URL`: Set to `https://[your-username].github.io/[repo-name]`

## 3. Enable GitHub Pages
1. Go to repository Settings → Pages
2. Under "Build and deployment":
   - Source: Deploy from a branch
   - Branch: gh-pages → /(root)
   - Click Save

## 4. Deploy Your Application
1. The deployment workflow (.github/workflows/deploy.yml) is already configured
2. It will:
   - Build your application
   - Deploy to the gh-pages branch
   - Use your external database
   - Handle environment variables

## 5. Trigger Initial Deployment
```bash
git add .
git commit -m "Configure for GitHub Pages deployment"
git push origin main
```

## 6. Verify Deployment
1. Wait for the GitHub Actions workflow to complete (check Actions tab)
2. Visit your GitHub Pages URL: https://[your-username].github.io/[repo-name]
3. Verify that:
   - The frontend loads correctly
   - API endpoints connect to your external database
   - User authentication works
   - Doctor listings are visible

## 7. Troubleshooting
If you encounter issues:
1. Check GitHub Actions logs for build errors
2. Verify all secrets are correctly set
3. Ensure your external database is accessible
4. Check if the VITE_API_URL matches your GitHub Pages URL exactly

## Note
- The application will automatically redeploy when you push changes to the main branch
- Your data remains safe in your external database
- Session management is handled through your external PostgreSQL database
