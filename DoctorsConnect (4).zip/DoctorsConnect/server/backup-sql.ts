
import { exec } from 'child_process';
import { promisify } from 'util';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const execAsync = promisify(exec);

async function backupDatabaseSQL() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupPath = `backup-${timestamp}.sql`;
  
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL is not set');
  }

  // Parse connection string
  const url = new URL(process.env.DATABASE_URL);
  const host = url.hostname;
  const port = url.port;
  const database = url.pathname.slice(1);
  const username = url.username;
  const password = url.password;

  // Construct pg_dump command
  const command = `PGPASSWORD=${password} pg_dump -h ${host} -p ${port} -U ${username} -d ${database} -F p > ${backupPath}`;

  try {
    await execAsync(command);
    console.log(`Backup created at: ${backupPath}`);
  } catch (error) {
    console.error('Backup failed:', error);
    throw error;
  }
}

// Run if this is the main module
backupDatabaseSQL()
  .then(() => process.exit(0))
  .catch(err => {
    console.error('Backup failed:', err);
    process.exit(1);
  });
