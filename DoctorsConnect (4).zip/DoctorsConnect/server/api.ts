import express from 'express';
import serverless from 'serverless-http';
import { registerRoutes } from './routes';

const app = express();
app.use(express.json());

const handler = async (event: any, context: any) => {
  const server = await registerRoutes(app);
  const serverlessHandler = serverless(app);
  return serverlessHandler(event, context);
};

export { handler };
