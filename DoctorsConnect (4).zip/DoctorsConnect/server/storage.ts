import { users, contactForms, type User, type InsertUser, type ContactForm, type InsertContactForm } from "@shared/schema";
import { db, withRetry } from "./db";
import { eq } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { generalInquiries, type GeneralInquiry, type InsertGeneralInquiry } from "@shared/schema";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getDoctors(): Promise<User[]>;
  updateDoctor(id: number, active: boolean): Promise<void>;
  createContactForm(form: InsertContactForm): Promise<ContactForm>;
  getContactFormsByDoctor(doctorId: number): Promise<ContactForm[]>;
  getAllContactForms(): Promise<ContactForm[]>;
  updateDoctorRating(doctorId: number, rating: number): Promise<void>;
  sessionStore: session.Store;
  createGeneralInquiry(inquiry: InsertGeneralInquiry): Promise<GeneralInquiry>;
  getGeneralInquiries(): Promise<GeneralInquiry[]>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      conObject: {
        connectionString: process.env.DATABASE_URL,
      },
      createTableIfMissing: true,
      pruneSessionInterval: 60, // Prune expired sessions every minute
      errorLog: console.error.bind(console),
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return await withRetry(async () => {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
    });
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return await withRetry(async () => {
      const [user] = await db.select().from(users).where(eq(users.username, username));
      return user;
    });
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    return await withRetry(async () => {
      const [user] = await db.insert(users).values({
        ...insertUser,
        isActive: true,
        rating: 0,
        ratingCount: 0,
      }).returning();
      return user;
    });
  }

  async getDoctors(): Promise<User[]> {
    return await withRetry(async () => {
      return await db.select().from(users).where(eq(users.role, 'doctor'));
    });
  }

  async updateDoctor(id: number, active: boolean): Promise<void> {
    await withRetry(async () => {
      await db.update(users)
        .set({ isActive: active })
        .where(eq(users.id, id));
    });
  }

  async createContactForm(form: InsertContactForm): Promise<ContactForm> {
    return await withRetry(async () => {
      const [contactForm] = await db.insert(contactForms)
        .values({
          ...form,
          createdAt: new Date(),
        })
        .returning();
      return contactForm;
    });
  }

  async getContactFormsByDoctor(doctorId: number): Promise<ContactForm[]> {
    return await withRetry(async () => {
      return await db.select()
        .from(contactForms)
        .where(eq(contactForms.doctorId, doctorId));
    });
  }

  async getAllContactForms(): Promise<ContactForm[]> {
    return await withRetry(async () => {
      return await db.select().from(contactForms);
    });
  }

  async updateDoctorRating(doctorId: number, rating: number): Promise<void> {
    await withRetry(async () => {
      const doctor = await this.getUser(doctorId);
      if (doctor) {
        const currentRating = doctor.rating || 0;
        const currentCount = doctor.ratingCount || 0;
        const newRatingCount = currentCount + 1;
        const newRating = Math.round(
          (currentRating * currentCount + rating) / newRatingCount
        );

        await db.update(users)
          .set({
            rating: newRating,
            ratingCount: newRatingCount,
          })
          .where(eq(users.id, doctorId));
      }
    });
  }

  async createGeneralInquiry(inquiry: InsertGeneralInquiry): Promise<GeneralInquiry> {
    return await withRetry(async () => {
      const [generalInquiry] = await db.insert(generalInquiries)
        .values({
          ...inquiry,
          createdAt: new Date(),
        })
        .returning();
      return generalInquiry;
    });
  }

  async getGeneralInquiries(): Promise<GeneralInquiry[]> {
    return await withRetry(async () => {
      return await db.select().from(generalInquiries);
    });
  }
}

export const storage = new DatabaseStorage();