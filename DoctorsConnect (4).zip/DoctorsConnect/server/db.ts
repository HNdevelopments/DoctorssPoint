import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  connectionTimeoutMillis: 5000, // 5 second timeout
  idleTimeoutMillis: 30000, // Close idle connections after 30 seconds
  max: 20, // Maximum number of clients in the pool
  ssl: {
    rejectUnauthorized: false // Allow self-signed certificates
  }
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
  process.exit(-1);
});

export const db = drizzle({ client: pool, schema });

export async function withRetry<T>(operation: () => Promise<T>, retries = 5): Promise<T> {
  let lastError;
  for (let i = 0; i < retries; i++) {
    try {
      return await operation();
    } catch (error: any) {
      console.error(`Database operation failed (attempt ${i + 1}/${retries}):`, error.message);
      lastError = error;

      // If the error is a connection error, wait longer
      const isConnectionError = error.message.includes('connection') || error.message.includes('timeout');
      const delay = isConnectionError 
        ? Math.min(2000 * Math.pow(2, i), 10000) // Max 10s delay for connection errors
        : Math.min(1000 * Math.pow(2, i), 5000);  // Max 5s delay for other errors

      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  throw lastError;
}

export { pool };