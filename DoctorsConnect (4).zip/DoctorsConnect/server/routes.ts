import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertContactFormSchema } from "@shared/schema";
import { insertGeneralInquirySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  app.get("/api/doctors", async (_req, res) => {
    try {
      const doctors = await storage.getDoctors();
      res.json(doctors);
    } catch (error) {
      console.error("Error fetching doctors:", error);
      res.status(500).send("Failed to fetch doctors");
    }
  });

  app.post("/api/contact", async (req, res) => {
    try {
      console.log("Received contact form submission:", req.body);
      const { doctorId, ...formData } = req.body;

      // If doctorId is provided, validate doctor
      if (doctorId) {
        const doctor = await storage.getUser(doctorId);
        if (!doctor || !doctor.isActive) {
          console.error(`Doctor not found or inactive. ID: ${doctorId}`);
          return res.status(404).send("Doctor not found or inactive");
        }
      }

      const parsed = insertContactFormSchema.safeParse({ ...formData, doctorId: doctorId || null });
      if (!parsed.success) {
        console.error("Form validation failed:", parsed.error);
        return res.status(400).json(parsed.error);
      }

      const form = await storage.createContactForm(parsed.data);
      console.log("Contact form created:", form);
      res.status(201).json(form);
    } catch (error) {
      console.error("Error creating contact form:", error);
      res.status(500).send("Failed to create contact form. Please try again.");
    }
  });

  app.get("/api/contact/:doctorId", async (req, res) => {
    if (!req.user || (req.user.role !== "doctor" && req.user.role !== "admin")) {
      return res.sendStatus(403);
    }

    const doctorId = parseInt(req.params.doctorId);
    if (req.user.role === "doctor" && req.user.id !== doctorId) {
      return res.sendStatus(403);
    }

    const forms = await storage.getContactFormsByDoctor(doctorId);
    res.json(forms);
  });

  app.get("/api/admin/contacts", async (req, res) => {
    if (!req.user || req.user.role !== "admin") {
      return res.sendStatus(403);
    }

    const forms = await storage.getAllContactForms();
    res.json(forms);
  });

  // New endpoint to get all general inquiries
  app.get("/api/admin/inquiries", async (req, res) => {
    if (!req.user || req.user.role !== "admin") {
      return res.sendStatus(403);
    }

    try {
      const inquiries = await storage.getGeneralInquiries();
      res.json(inquiries);
    } catch (error) {
      console.error("Error fetching general inquiries:", error);
      res.status(500).send("Failed to fetch general inquiries");
    }
  });

  app.post("/api/admin/doctors/:id/toggle", async (req, res) => {
    const { password } = req.body;
    const masterPassword = process.env.MASTER_PASSWORD;

    if (!masterPassword || password !== masterPassword) {
      return res.status(403).send("Invalid master password");
    }

    const doctorId = parseInt(req.params.id);
    const doctor = await storage.getUser(doctorId);

    if (!doctor || doctor.role !== "doctor") {
      return res.status(404).send("Doctor not found");
    }

    await storage.updateDoctor(doctorId, !doctor.isActive);
    res.sendStatus(200);
  });

  app.post("/api/doctors/:id/rate", async (req, res) => {
    const doctorId = parseInt(req.params.id);
    const rating = parseInt(req.body.rating);

    if (isNaN(rating) || rating < 1 || rating > 5) {
      return res.status(400).send("Invalid rating");
    }

    const doctor = await storage.getUser(doctorId);
    if (!doctor || !doctor.isActive) {
      return res.status(404).send("Doctor not found or inactive");
    }

    await storage.updateDoctorRating(doctorId, rating);
    res.sendStatus(200);
  });

  app.post("/api/contact/general", async (req, res) => {
    try {
      const parsed = insertGeneralInquirySchema.safeParse(req.body);
      if (!parsed.success) {
        console.error("Form validation failed:", parsed.error);
        return res.status(400).json(parsed.error);
      }

      const inquiry = await storage.createGeneralInquiry(parsed.data);
      console.log("General inquiry created:", inquiry);
      res.status(201).json(inquiry);
    } catch (error) {
      console.error("Error creating general inquiry:", error);
      res.status(500).send("Failed to submit inquiry. Please try again.");
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}